package decorator;

import java.text.DecimalFormat;

public class TestDeco {

	public static void main(String[] args) {
			Boisson b=new Chantilly(new Lait(new Expresso()));
			
			DecimalFormat df = new DecimalFormat("##.##");

			System.out.println(b.getDescription() + " :  "+df.format(b.cout())+ " euros");
	}

}
