package decorator;

public abstract class DecorateurIngredient extends Boisson {

	//boisson décorée
	protected Boisson boisson;
	
	public DecorateurIngredient(Boisson boisson) {
		this.boisson=boisson;
	}

	

}
