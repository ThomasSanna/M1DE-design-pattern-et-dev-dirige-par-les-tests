package decorator;

public class Colombia extends Boisson {

	public Colombia() {
		this.description="Colombia";
	}

	@Override
	public double cout() {
		return 1.5;
	}

}
