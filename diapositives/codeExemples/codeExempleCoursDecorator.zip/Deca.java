package decorator;

public class Deca extends Boisson {
	private static final double COUTDECA=2;
	public Deca() {
		this.description="Deca";
	}

	@Override
	public double cout() {
		return COUTDECA;
	}

}
