package commandPlus;

public interface Commande {
	   public void executer() ;
	   public void annuler() ;}
