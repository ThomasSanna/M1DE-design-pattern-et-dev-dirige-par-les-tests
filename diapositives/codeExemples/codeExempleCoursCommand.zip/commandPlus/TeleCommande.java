package commandPlus;

public class TeleCommande {
	  	
	Commande c;
	
	 public void setCom(Commande c){
	    this.c=c;}
	 
	  public void presserBtn1() {
	    c.executer();}
	  
	 public void presserBtn2() {
	    c.annuler();}
	}

