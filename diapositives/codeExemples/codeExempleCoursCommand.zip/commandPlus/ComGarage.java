package commandPlus;
public class ComGarage implements Commande {
	   PorteGarage g;
	   
	   public ComGarage(PorteGarage g) {
	     this.g = g;
	   }
	   public void executer() {
		    g.ouvrir();
	   }
	   public void annuler() {
		    g.fermer();
	   }

}
