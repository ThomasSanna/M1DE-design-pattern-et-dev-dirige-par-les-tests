package commandPlus;
public class ComLampe implements Commande {
	   Lampe lampe;
	   
	   public ComLampe(Lampe lampe) {
	     this.lampe = lampe;
	   }
	   public void executer() {
	    lampe.allumer();
	   }
	   public void annuler() {
		  lampe.eteindre();
	   }
	}
