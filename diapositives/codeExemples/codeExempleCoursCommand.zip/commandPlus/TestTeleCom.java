package commandPlus;

public class TestTeleCom{
	public static void main(String[] args) {
     //Invocateur 
	TeleCommande telecom=new TeleCommande(); 
     //Receveur 
    Lampe l = new Lampe(); 
     //Commandes
    Commande cl= new ComLampe(l);
 	
    telecom.setCom(cl);
 
	telecom.presserBtn1();
	telecom.presserBtn2();
	
	//Reprogramation de la télécommande
     PorteGarage g = new PorteGarage(); 
     Commande cg= new ComGarage(g);
     telecom.setCom(cg);
 	  	 
	 telecom.presserBtn1();
	 telecom.presserBtn2();
	
	}

}
