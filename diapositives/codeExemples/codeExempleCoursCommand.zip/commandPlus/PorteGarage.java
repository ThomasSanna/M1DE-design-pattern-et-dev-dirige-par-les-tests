package commandPlus;

public class PorteGarage {

	public void ouvrir() {
		System.out.println("La porte est ouverte");
	}
	public void fermer() {
		System.out.println("La porte est fermée");
	}

}
