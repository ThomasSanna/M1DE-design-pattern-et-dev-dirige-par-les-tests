package commandProblem;

public class TestTeleCom{
	public static void main(String[] args) {
	    Lampe l = new Lampe(); 
		TeleCommande telecom=new TeleCommande(l); 
		telecom.presserBtn1();		
		telecom.presserBtn2();
	}

}
