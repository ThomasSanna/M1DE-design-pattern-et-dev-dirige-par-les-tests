package commandProblem;

public class TeleCommande {
	Lampe lp;
	
	public TeleCommande(Lampe lp){
		this.lp=lp;}
	public void presserBtn1() {
		lp.allumer();}
	public void presserBtn2() {
		lp.eteindre();}
}


