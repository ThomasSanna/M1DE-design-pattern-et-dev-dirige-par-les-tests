package command;
public class ComOGarage implements Commande {
	   PorteGarage g;
	   
	   public ComOGarage(PorteGarage g) {
	     this.g = g;
	   }
	   public void executer() {
	    g.ouvrir();
	   }
	}
