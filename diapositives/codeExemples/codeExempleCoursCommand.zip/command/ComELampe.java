package command;

public class ComELampe implements Commande {
	   Lampe lampe;
	   
	   public ComELampe(Lampe lampe) {
	     this.lampe = lampe;
	   }
	   public void executer() {
	    lampe.eteindre();
	   }

}
