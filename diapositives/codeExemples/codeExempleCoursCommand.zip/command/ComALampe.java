package command;
public class ComALampe implements Commande {
	   Lampe lampe;
	   
	   public ComALampe(Lampe lampe) {
	     this.lampe = lampe;
	   }
	   public void executer() {
	    lampe.allumer();
	   }
	}
