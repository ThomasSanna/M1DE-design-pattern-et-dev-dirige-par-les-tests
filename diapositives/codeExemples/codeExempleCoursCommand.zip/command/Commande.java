package command;

public interface Commande {
	   public void executer() ;
}
