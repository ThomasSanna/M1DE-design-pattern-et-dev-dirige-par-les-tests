package command;
public class ComFGarage implements Commande {
	   Lampe lampe;
	   PorteGarage g;
	   
	   public ComFGarage(PorteGarage g) {
	     this.g = g;
	   }
	   public void executer() {
	    g.fermer();
	   }
	}
