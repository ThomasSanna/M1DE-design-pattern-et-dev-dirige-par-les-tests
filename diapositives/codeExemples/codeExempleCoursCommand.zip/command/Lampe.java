package command;

public class Lampe {

	public void allumer() {
		System.out.println("La lampe est allumée");
	}
	public void eteindre() {
		System.out.println("La lampe est éteinte");
	}

}
