package command;

public class TeleCommande {
	  	
	Commande c1,c2;
	 public void setBtn1(Commande c){
	    this.c1=c;}
	 
	 public void setBtn2(Commande c){
	    this.c2=c;}
	 
	  public void presserBtn1() {
	    c1.executer();}
	  
	 public void presserBtn2() {
	    c2.executer();}
	}

