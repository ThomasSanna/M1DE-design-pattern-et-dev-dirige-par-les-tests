package command;

public class TestTeleCom{
	public static void main(String[] args) {
     //Invocateur 
	TeleCommande telecom=new TeleCommande(); 
     //Receveur 
    Lampe l = new Lampe(); 
     //Commandes
    Commande lal= new ComALampe(l);
 	Commande let= new ComELampe(l);
 	
    telecom.setBtn1 (lal);
    telecom.setBtn2 (let);  

	telecom.presserBtn1();
	telecom.presserBtn2();
	
	//Reprogramation de la télécommande
     PorteGarage g = new PorteGarage(); 
     Commande log= new ComOGarage(g);
 	 Commande lfg= new ComFGarage(g);      
     telecom.setBtn1 (log);
  	 telecom.setBtn2 (lfg);
	  	 
	 telecom.presserBtn1();
	 telecom.presserBtn2();
	
	}

}
