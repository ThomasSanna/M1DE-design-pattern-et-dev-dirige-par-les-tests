package composite;


public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Initialisation des graphiques
		Graphique g1=new Ligne();
		Graphique g2=new Texte();
		Graphique g3=new Ligne();
		Graphique g4=new Image();
		Graphique g5=new Image();
		//Ajout des graphiques composant les images
		g4.ajouter(g1);
		g4.ajouter(g2);
		g4.ajouter(g3);
		
		g5.ajouter(g4);
		g5.ajouter(g1);

		g4.dessiner("");
		System.out.println();
		g5.dessiner("");
		
		

	}

}
