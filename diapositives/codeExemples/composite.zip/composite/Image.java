package composite;

import java.util.ArrayList;

public class Image extends Graphique {
	//graphique qui peut comporter plusieurs composants
	private ArrayList<Graphique> graphiques; //liste des composants de l'image

    public Image(){
    		graphiques=new ArrayList<Graphique>();
    }
    public Graphique getEnfant(int num) {
    	return graphiques.get(num);
    };
    public void ajouter(Graphique g){
		graphiques.add(g);
	}
    public void supprimer(Graphique g) {
		graphiques.remove(g);
	}

    @Override
    public void dessiner(String tab) {
		System.out.println();
		System.out.println(tab+"**** Dessin Image "+ num + " **** : ");
		for (int i=0;i<graphiques.size(); i++) {		
			System.out.print("  " +tab+"composant " + (i +1) + " : " );
			graphiques.get(i).dessiner("  " +tab);
		}
		System.out.println(tab+"**** Fin image "+ num + " ********");
	}

}
