package composite;

public class Rectangle extends Graphique {

	public Rectangle() {
	}

	
	@Override
	public void dessiner(String tab) {
		System.out.println(tab+"Dessin du rectangle  "+ num);
	}



}
