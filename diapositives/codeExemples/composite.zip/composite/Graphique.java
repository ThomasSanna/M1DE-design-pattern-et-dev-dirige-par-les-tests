package composite;



public abstract class Graphique {
		protected int num;
		private static int nbGraphique=0;
		public Graphique() {
			nbGraphique++;
			num=nbGraphique;
		}
	    
	    public abstract void dessiner(String tab);
	    
		public Graphique getEnfant(int num) {
			return null;
		}
		
		public void ajouter(Graphique g) {
			   throw new UnsupportedOperationException("Opération non supportée pour un élément simple");

		}

		
		public void supprimer(Graphique g) {
			throw new UnsupportedOperationException("Opération non supportée pour un élément simple");

		}

}
