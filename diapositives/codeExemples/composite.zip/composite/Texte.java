package composite;

public class Texte extends Graphique {

	public Texte() {
	}

	@Override
	public void dessiner(String tab) {
		System.out.println(tab+"Dessin du texte numéro "+ num);

	}


}
