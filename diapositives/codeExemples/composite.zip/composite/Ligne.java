package composite;

public class Ligne extends Graphique {

	public Ligne() {
	}

	@Override
	public void dessiner(String tab) {
		System.out.println(tab+"Dessin de la ligne numéro "+ num);
	}

	

}
