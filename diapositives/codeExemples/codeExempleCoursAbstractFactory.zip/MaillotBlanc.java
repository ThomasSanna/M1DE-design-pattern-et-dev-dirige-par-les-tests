package abstractFactory;

public class MaillotBlanc extends Maillot {

	public MaillotBlanc(String taille) {
		super(taille);
	}

	public String toString() {
		return "Maillot blanc " + super.toString();		
	}
}
