package abstractFactory;

public class FabriqueTenueDom implements FabriqueTenue {


	@Override
	public Maillot creerMaillot(String taille) {
		return new MaillotBlanc(taille);
	}

	@Override
	public Short creerShort(int taille) {
		return new ShortRouge(taille);
	}

}
