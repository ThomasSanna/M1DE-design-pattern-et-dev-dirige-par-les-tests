package abstractFactory;

public interface FabriqueTenue {

	public Maillot creerMaillot(String taille);
	public Short creerShort(int taille);

}
