package abstractFactory;

public class MaillotBleu extends Maillot {

	public MaillotBleu(String taille) {
		super(taille);
	}

	public String toString() {
		return "Maillot bleu " + super.toString();		
	}
}
