package abstractFactory;

public abstract class Short {
	private int taille;
	
	public Short(int taille) {
		this.taille=taille;
	}

	public String toString() {
		return "de taille "+taille;
	}
}
