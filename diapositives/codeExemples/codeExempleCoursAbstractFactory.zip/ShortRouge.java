package abstractFactory;

public class ShortRouge extends Short{

	public ShortRouge(int taille) {
		super(taille);
	}

	public String toString() {
		return "Short rouge " + super.toString();		
	}	

}
