package abstractFactory;

public abstract class Maillot {
	
	private String taille;
	
	public Maillot(String taille) {
		this.taille=taille;
	}

	public String toString() {
		return "de taille "+taille;
	}

}
