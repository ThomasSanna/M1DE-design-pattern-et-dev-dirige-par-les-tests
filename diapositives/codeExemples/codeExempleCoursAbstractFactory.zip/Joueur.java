package abstractFactory;

public class Joueur {
	private String nom;
	private Maillot monMaillot;
	private Short monShort;
	
	private String tailleMaillot;
	private int tailleShort;
	
	public Joueur(String nom,String tailleMaillot, int tailleShort,FabriqueTenue f) {
		this.nom=nom;
		monMaillot=f.creerMaillot(tailleMaillot);
		monShort=f.creerShort(tailleShort);
	}
	public void jouer() {
		System.out.println(nom + " joue avec un "+monShort + " et un "+monMaillot);
	}

	public void changerTenue(FabriqueTenue f) {
		monMaillot=f.creerMaillot(tailleMaillot);
		monShort=f.creerShort(tailleShort);		
	}
}
