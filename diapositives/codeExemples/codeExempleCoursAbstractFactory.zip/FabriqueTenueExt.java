package abstractFactory;

public class FabriqueTenueExt implements FabriqueTenue {


	@Override
	public Maillot creerMaillot(String taille) {
		return new MaillotBleu(taille);
	}

	@Override
	public Short creerShort(int taille) {
		return new ShortNoir(taille);
	}

}
