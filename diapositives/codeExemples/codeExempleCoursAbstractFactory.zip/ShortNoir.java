package abstractFactory;

public class ShortNoir extends Short{

	public ShortNoir(int taille) {
		super(taille);
	}

	public String toString() {
		return "Short noir " + super.toString();
		
	}


}
