package abstractFactory;

public class testJoueur {


	public static void main(String[] args) {
		FabriqueTenue fab=new FabriqueTenueDom();
		Joueur j=new Joueur("toto","S",2,fab);
		j.jouer();
	}

}
