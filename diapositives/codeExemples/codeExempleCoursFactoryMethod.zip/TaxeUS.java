package factoryMethod;

public class TaxeUS extends Taxe {
    private static final double TAUXUS=0.35;
	
	public double getTaux() {
		return TAUXUS;
	}

}
