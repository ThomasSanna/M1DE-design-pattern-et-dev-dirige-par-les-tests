package factoryMethod;

public class TaxeCorse extends Taxe {
    private static final double TAUXCORSE=0.15;
	
	public double getTaux() {
		return TAUXCORSE;
	}

}
