package factoryMethod;

public abstract class Taxe {

	public Taxe() {
		// TODO Auto-generated constructor stub
	}

}
