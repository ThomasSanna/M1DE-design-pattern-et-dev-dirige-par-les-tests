package factoryMethod;

public abstract class Commande {
	private Taxe maTaxe;

	public Commande() {
		//instanciation de la taxe
		maTaxe=creerTaxe();		
	}
	abstract private Taxe creerTaxe();

}
