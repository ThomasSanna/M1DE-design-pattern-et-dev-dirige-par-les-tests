package factoryMethod;

public class CommandeCorse extends Commande {

	public CommandeCorse() {
		// TODO Auto-generated constructor stub
	}
	private Taxe creerTaxe() {
		return new TaxeCorse();
	};

}
