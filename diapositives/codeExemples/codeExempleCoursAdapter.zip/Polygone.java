package adapter;

public class Polygone {

	public Polygone() {
		// TODO Auto-generated constructor stub
	}
	public void afficherPoly() {
		System.out.println("affichage du polygone");
	}

}
