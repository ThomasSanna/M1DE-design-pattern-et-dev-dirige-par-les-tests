package adapter;

public class PolygoneAdapt2 extends Polygone implements Forme {
//Version adaptateur de classe

	@Override
	public void afficher() {
		afficherPoly();
	}
	@Override
	public void agrandir() {
		System.out.println("agrandissement du polygone");
	}


}
