package adapter;

public class TestFormes {

	public static void main(String[] args) {
	//Version adaptateur d'objet
		Forme f= new PolygoneAdapt();;
		Editeur e= new Editeur(f);
		e.testerForme();
	//Version adaptateur de classe
		f= new PolygoneAdapt2();;
		e.setF(f);
		e.testerForme();
	}

}
