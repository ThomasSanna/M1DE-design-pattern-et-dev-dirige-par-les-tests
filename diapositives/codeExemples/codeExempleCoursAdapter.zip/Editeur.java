package adapter;

public class Editeur {
	private Forme f;
	
	public void setF(Forme f) {
		this.f = f;
	}
	public Editeur(Forme f) {
		this.f=f;
	}
	public void testerForme() {
		f.afficher();
		f.agrandir();
	}

}
