package adapter;

public interface Forme {

	public void afficher();
	public void agrandir();
}
