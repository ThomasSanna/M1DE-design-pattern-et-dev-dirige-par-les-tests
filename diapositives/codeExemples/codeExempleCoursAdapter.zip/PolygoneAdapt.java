package adapter;

public class PolygoneAdapt implements Forme{
//Version adaptateur d'objet
	 
	private Polygone p;
	
	public PolygoneAdapt() {
		this.p=new Polygone();
	}

	@Override
	public void afficher() {
		p.afficherPoly();
	}

	@Override
	public void agrandir() {
		System.out.println("agrandissement du polygone");
	}

}
