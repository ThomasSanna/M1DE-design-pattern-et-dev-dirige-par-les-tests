package observer;

import java.util.ArrayList;

public abstract class Mesures {
	//classe diffuseur
	
	private ArrayList<DispositifAffichage> dispositifs;//observateurs

	public Mesures() {
		dispositifs=new ArrayList<DispositifAffichage> ();
	}

	public void ajouterDispositif(DispositifAffichage d) {
		dispositifs.add(d);
		
	}
	public void notifierDispositifs() {
		for (DispositifAffichage d : dispositifs) {
			d.actualiser();
		}
	}
}
