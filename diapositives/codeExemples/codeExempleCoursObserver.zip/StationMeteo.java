package observer;

public class StationMeteo {

	public static void main(String args[]) {
		DonneeMeteo donnees=new DonneeMeteo();
		DispositifAffichage affichageCond=new AffichageCond(donnees) ;
		DispositifAffichage affichageStat=new AffichageStat(donnees) ;
		//Simulation mise à jour des données de la station méteo
		donnees.setMesures(10,65,1000);
		donnees.setMesures(13,70,1100);
		donnees.setMesures(8,65,1000);
	}
}
