package observer;

public interface DispositifAffichage {

	public void actualiser();
}
