package observer;

import java.time.LocalDateTime;

public class DonneeMeteo extends Mesures{
	private double temp;
	private double humidite;
	private double pression;
	
	public DonneeMeteo() {
		super();
	}
	
	public void setMesures(double temp,double humidite,double pression) {
		this.temp = temp;
		this.humidite = humidite;
		this.pression = pression;
		LocalDateTime toDay=LocalDateTime.now();
		System.out.println("**************************************************");
		System.out.println("Nouvelles Données du "+toDay);
		System.out.println("**************************************************");

		notifierDispositifs();
	}
	public double getTemp() {
		return temp;
	}
	public double getHumidite() {
		return humidite;
	}
	public double getPression() {
		return pression;
	}
}
