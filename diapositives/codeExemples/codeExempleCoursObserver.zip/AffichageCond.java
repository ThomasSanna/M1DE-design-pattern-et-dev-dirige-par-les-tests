package observer;

public class AffichageCond implements DispositifAffichage{
	
	private DonneeMeteo donneeM;
	
	private double temp;
	private double humidite;
	private double pression;
	
	public AffichageCond(DonneeMeteo donneeM) {
		this.donneeM=donneeM;
		donneeM.ajouterDispositif(this);
		//Ajout à la liste des dispositifs de donneeM
	}
	
	private void afficher() {
		System.out.println("*****Affichage Cond *****");
		System.out.println("Température : "+temp);
		System.out.println("Humidité : "+humidite);
		System.out.println("Pression : "+pression);
	}


	@Override
	public void actualiser() {
		//se met à jour auprés du diffuseur
		this.temp=donneeM.getTemp();
		this.humidite=donneeM.getHumidite();
		this.pression=donneeM.getPression();
		afficher();
	}

}
