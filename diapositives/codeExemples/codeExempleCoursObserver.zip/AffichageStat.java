package observer;

import java.text.NumberFormat;
import java.time.LocalDate;


public class AffichageStat implements DispositifAffichage{
	
	private DonneeMeteo donneeM;
	
	private double temp;
	
	private int nbDonnees=0;
	private double somTemp=0;
	private double maxTemp=0;
	private double minTemp=0;


	public AffichageStat(DonneeMeteo donneeM) {
		this.donneeM=donneeM;
		donneeM.ajouterDispositif(this);//s'abonne au diffuseur
	}
	
	private void afficher() {
		System.out.println("*****Affichage Stat *****");
		if (nbDonnees==0)
			System.out.println("Aucune donnée pour l'instant");
		else {
			NumberFormat f = NumberFormat.getNumberInstance();
			f.setMaximumFractionDigits(2);
			System.out.println("Moyenne Temperatures : "+ f.format(somTemp/nbDonnees) );
			System.out.println("Température minimum : "+minTemp);
			System.out.println("Température maximum : "+maxTemp);
		}
	}
	private void majStat() {
		nbDonnees++;
		somTemp+=temp;
		if (nbDonnees==1) {
			minTemp=temp;
			maxTemp=temp;
		}
		else
			if (temp>maxTemp)
				maxTemp=temp;
			else
				if (temp<minTemp)
					minTemp=temp;
	}

	@Override
	public void actualiser() {		
		this.temp=donneeM.getTemp();//se met à jour auprés du diffuseur
		majStat();
		afficher();
	}

}
