package proxy;

public interface Graphique {

	public void afficher();
	public double getTaille();
	public void sauvegarder();
	public void charger();
}
