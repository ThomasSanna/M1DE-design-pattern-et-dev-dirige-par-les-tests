package proxy;

public class ProxyImage implements Graphique {
	
	private Image image;
	
	private double taille;
	private String fileName;
	
	public ProxyImage(double taille, String fileName) {
		this.taille = taille;
		this.fileName = fileName;
		image=null;
		System.out.println("L'image " + fileName + " est en attente de chargement");
	}

	@Override
	public void afficher() {
		if (image==null)
			image=new Image(fileName);
		image.afficher();
	}

	@Override
	public double getTaille() {
		double res=taille;
		if (image!=null)
			res=image.getTaille();
		return res;

	}

	@Override
	public void sauvegarder() {
		if (image==null)
			image=new Image(fileName);
		image.sauvegarder();
	}

	@Override
	public void charger() {
		if (image==null)
			image=new Image(fileName);
		image.charger();
	}

}
