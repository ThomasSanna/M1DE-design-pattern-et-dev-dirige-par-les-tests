package proxy;

public class Image implements Graphique {
	private double taille;
	//private ImageTec imageOriginale;
	//instance d'une classe spécifique 
	
	private String fileName;
	
	public Image(String fileName) {
		this.fileName=fileName;
	    charger();
	}

	@Override
	public void afficher() {
		System.out.println("Affichage de l'image : " + fileName);
	}

	@Override
	public double getTaille() {
		return taille;
	}

	@Override
	public void sauvegarder() {
		System.out.println("Sauvegarde de l'image ");
	}

	@Override
	public void charger() {		
		// initialisation de l'attribut imageOriginale
		System.out.println("Chargement de l'image : "+ fileName);
	}

}
