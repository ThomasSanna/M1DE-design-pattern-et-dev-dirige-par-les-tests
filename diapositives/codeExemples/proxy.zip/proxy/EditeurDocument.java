package proxy;

public class EditeurDocument {
	private Graphique g;
	public EditeurDocument(Graphique g) {
		this.g=g;	
	}
	
	private void afficherGraphique() {
		System.out.println("Demande d'affichage ---->");
		g.afficher();
	}

	public static void main(String[] args) {
		
		EditeurDocument e1=new EditeurDocument(new Image("unExemple1.jpeg"));
		//Création et chargement de l'image
		e1.afficherGraphique();
		System.out.println("*********************************************");
	
		EditeurDocument e2=new EditeurDocument(new ProxyImage(256,"unExemple2.jpeg"));
		//Pas de chargement de l'image
		
		e2.afficherGraphique();
		
		
	}
}
