package strategySolPattern;

public class ChantNul implements ComportementChant {


	@Override
	public void faireCoinCoin() {
		//ne rien faire
		//System.out.println("Je ne sais pas faireCoinCoin!!");
	}

}
