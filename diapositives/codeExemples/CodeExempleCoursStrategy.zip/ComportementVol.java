package strategySolPattern;

public interface ComportementVol {
	public  void voler();
}
