package strategySolPattern;

public class ChantNormal implements ComportementChant {

	

	@Override
	public void faireCoinCoin() {
		System.out.println("Je fais coincoin!!");

	}

}
