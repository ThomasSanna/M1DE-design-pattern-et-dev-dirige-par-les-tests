package strategySolPattern;

public class Fuligule extends Canard {

	public Fuligule(String nom) {
		super(nom);
		monVol=new VolNormal();
		monChant= new ChantNormal();
		
	}
	
	@Override
	public void afficher() {
		System.out.println(this +" de type Fuligule");
	}

}
