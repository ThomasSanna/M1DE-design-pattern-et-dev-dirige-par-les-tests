package strategySolPattern;

class VolNormal implements ComportementVol {

	

	@Override
	public  void voler(){
		System.out.println("Je vole, je vole!!");
	};

}
