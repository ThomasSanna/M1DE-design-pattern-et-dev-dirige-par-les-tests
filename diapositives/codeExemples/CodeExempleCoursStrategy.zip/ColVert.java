package strategySolPattern;

public class ColVert extends Canard {

	public ColVert(String nom) {
		super(nom);
		monVol=new VolNormal();
		monChant= new ChantNormal();
		
	}


	@Override
	public void afficher() {
		System.out.println(this +" de type Col Vert");

	}

}
