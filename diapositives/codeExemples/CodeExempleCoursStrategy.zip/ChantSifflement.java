package strategySolPattern;

public class ChantSifflement implements ComportementChant {

	

	@Override
	public void faireCoinCoin() {
		System.out.println("Je siffle!!");
	}

}
