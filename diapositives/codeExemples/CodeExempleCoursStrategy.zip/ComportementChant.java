package strategySolPattern;

public interface ComportementChant {
	public  void faireCoinCoin();
}
