package strategySolPattern;

public class TestStrategy {

	
	public static void main(String[] args) {
		Canard c=new CanardSuper("Toto");
		c.afficher();
		c.voler();
		c.faireCoincoin();
		ComportementVol comp=new VolNormal();
	    c.setComportementVol(comp);
		c.voler();
	}

}
