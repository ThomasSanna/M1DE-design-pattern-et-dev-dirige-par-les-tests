package strategySolPattern;

public class VolSupersonique implements ComportementVol {

	public VolSupersonique() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void voler() {
		System.out.println("Je vole à une vitesse supersonique!!");

	}

}
