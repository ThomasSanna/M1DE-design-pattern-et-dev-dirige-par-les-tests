package strategySolPattern;

public abstract class Canard {
	protected String nom;
	protected ComportementVol monVol;
	protected ComportementChant monChant;

	public Canard(String nom) {
		this.nom=nom;
	}
	public  void faireCoincoin(){
		monChant.faireCoinCoin();
	};
	public  void voler(){
		monVol.voler();
	};
	
	public void setComportementVol(ComportementVol monVol){
		this.monVol=monVol;
	}
	public void nager() {
		System.out.println("Je nage!!");
	};
	public abstract void afficher();

	public String toString() {
		return nom;
	}
}
