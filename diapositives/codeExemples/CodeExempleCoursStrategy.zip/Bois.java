package strategySolPattern;


public class Bois extends Canard {

	public Bois(String nom) {
		super(nom);
		monVol=new VolNul();
		monChant= new ChantNul();
	}


	@Override
	public void afficher() {
		System.out.println(this +" de type Bois");
	}

}
