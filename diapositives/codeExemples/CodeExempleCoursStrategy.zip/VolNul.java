package strategySolPattern;

public class VolNul implements ComportementVol {

	

	@Override
	public void voler() {
		//ne rien faire
		//System.out.println("Je ne sais pas voler!!");
	};

}
