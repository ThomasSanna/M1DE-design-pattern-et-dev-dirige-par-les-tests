package strategySolPattern;

public class CanardSuper extends Canard {

	public CanardSuper(String nom) {
		super(nom);
		monVol=new VolSupersonique();
		monChant= new ChantSifflement();
	}

	@Override
	public void afficher() {
		System.out.println(this +" de type Super");

	}

}
