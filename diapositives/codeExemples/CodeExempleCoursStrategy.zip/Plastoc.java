package strategySolPattern;


public class Plastoc extends Canard {

	public Plastoc(String nom) {
		super(nom);
		monVol=new VolNul();
		monChant= new ChantSifflement();
	}
	
	
	@Override
	public void afficher() {
		System.out.println(this +" de type Plastoc");

	}

}
