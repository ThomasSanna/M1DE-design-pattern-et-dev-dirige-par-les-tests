package state;

public abstract class Etat {
	
    protected Distributeur monD;
    
	public Etat(Distributeur monD) {
		this.monD=monD;
	}
	public abstract void remplir();
	public abstract void insererPiece();
	public abstract void delivrerBonbons();	
	public abstract void tournerPoignee();
	public abstract void ejecterPieces();
}
