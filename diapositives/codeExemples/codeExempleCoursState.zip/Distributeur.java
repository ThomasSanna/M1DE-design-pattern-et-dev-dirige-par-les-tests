package state;

public class Distributeur {
	private Etat monEtat;
	
	private int nbBonbons;
	
	public Distributeur() {
		monEtat=new Vide(this);
	}	
	public int getNbBonbons() {
		return nbBonbons;		
	}
	public void setNbBonbons(int nbBonbons) {
		this.nbBonbons=nbBonbons;
	}
	public void ajouterBonbons() {
		nbBonbons++;
	}
	public void enleverBonbons() {
		nbBonbons--;
	}	
	public void remplir() {
		System.out.println("**Remplissage**");
		monEtat.remplir();
	}
	public void insererPiece() {
		System.out.println("**Insertion pièce**");
		monEtat.insererPiece();
	}	
	public void tournerPoignee() {
		System.out.println("**Poignée tournée**");
		monEtat.tournerPoignee();
	}	
	public void ejecterPieces() {
		System.out.println("**Ejection pièce**");
		monEtat.ejecterPieces();
	}	
	public void delivrerBonbons() {
		System.out.println("**Délivrance bonbons**");
		monEtat.delivrerBonbons();
	}	
	public void changerEtat(Etat monEtat) {
		this.monEtat = monEtat;
	}

	public String toString() {
		return "Etat du distributeur : " + monEtat.getClass().getSimpleName() 
				+ "\nNombre de bonbons : "+nbBonbons;
	}
}
