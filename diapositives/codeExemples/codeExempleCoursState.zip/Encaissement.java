package state;

public class Encaissement extends Etat {

	public Encaissement(Distributeur monD) {
		super(monD);
	}

	@Override
	public void remplir() {
		System.out.println("!!!!Erreur remplissage impossible");
	}

	@Override
	public void insererPiece() {
		System.out.println("!!!!Erreur insertion impossible");
	}

	@Override
	public void delivrerBonbons() {
		System.out.println("!!! Erreur il faut d'abord tourner la poignée");
	}

	@Override
	public void tournerPoignee() {
		monD.changerEtat(new Distribution(monD));
	}

	@Override
	public void ejecterPieces() {
		monD.changerEtat(new Attente(monD));
	}

}
