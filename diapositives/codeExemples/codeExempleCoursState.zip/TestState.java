package state;

public class TestState {

	public TestState() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Distributeur d =new Distributeur();
		System.out.println(d);
		d.remplir();
		System.out.println(d);
		d.insererPiece();
		System.out.println(d);
		d.tournerPoignee();
		System.out.println(d);
		d.delivrerBonbons();
		System.out.println(d);
		d.insererPiece();
		System.out.println(d);
		d.tournerPoignee();
		System.out.println(d);
		d.insererPiece();
		System.out.println(d);
		d.delivrerBonbons();
		System.out.println(d);
		d.delivrerBonbons();
		d.remplir();
		System.out.println(d);
	}

}
