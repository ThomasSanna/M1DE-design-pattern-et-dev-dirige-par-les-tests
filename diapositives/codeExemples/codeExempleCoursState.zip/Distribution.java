package state;

public class Distribution extends Etat {

	public Distribution(Distributeur monD) {
		super(monD);
	}

	@Override
	public void remplir() {
		System.out.println("!!!!Erreur remplissage impossible");
	}

	@Override
	public void insererPiece() {
		System.out.println("!!!!Erreur opération impossible");
	}

	@Override
	public void delivrerBonbons() {
		monD.enleverBonbons();
		if (monD.getNbBonbons()==0) {
			monD.changerEtat(new Vide(monD));}
		else
			monD.changerEtat(new Attente(monD));	
	}

	@Override
	public void tournerPoignee() {
		System.out.println("!!!!Erreur opération impossible");
	}

	@Override
	public void ejecterPieces() {
		System.out.println("!!!!Erreur opération impossible");
	}

}
