package state;

public class Vide extends Etat {
	private final static int NBMAX=2;
	
	public Vide(Distributeur monD) {
		super(monD);
	}

	@Override
	public void remplir() {
		monD.setNbBonbons(NBMAX);
		monD.changerEtat(new Attente(monD));
		
	}

	@Override
	public void insererPiece() {
		System.out.println("!!!!Erreur insertion impossible");
	}

	@Override
	public void delivrerBonbons() {
		System.out.println("!!!!Erreur délivrance impossible");
	}

	@Override
	public void tournerPoignee() {
		System.out.println("!!!!Erreur opération impossible");
	}

	@Override
	public void ejecterPieces() {
		System.out.println("!!!!Erreur opération impossible");
	}

}
