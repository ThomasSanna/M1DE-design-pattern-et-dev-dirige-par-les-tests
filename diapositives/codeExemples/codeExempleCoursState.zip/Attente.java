package state;

public class Attente extends Etat {

	public Attente(Distributeur monD) {
		super(monD);
	}
	@Override
	public void remplir() {
		System.out.println("!!!!Erreur remplissage impossible");
	}

	@Override
	public void insererPiece() {
		monD.changerEtat(new Encaissement(monD));
	}

	@Override
	public void delivrerBonbons() {
		System.out.println("!!!!Erreur délivrance impossible");
	}

	@Override
	public void tournerPoignee() {
		System.out.println("!!!!Erreur opération impossible");
	}

	@Override
	public void ejecterPieces() {
		System.err.println("Erreur impossible");
	}

}
